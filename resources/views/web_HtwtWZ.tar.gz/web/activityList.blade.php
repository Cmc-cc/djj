<!DOCTYPE html>
<!-- saved from url=(0029)/activity -->
<html class="s-app translated-ltr" lang="zh-CN" data-n-head="%7B%22lang%22:%7B%22ssr%22:%22zh-TW%22%7D%7D">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $_system_config->site_title  or 'motoo' }}</title>
    <meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1">
    <meta data-n-head="ssr" data-hid="keywords" name="keywords"
          content="娛樂城體育,娛樂城優惠,線上娛樂城,娛樂城註冊優惠,現金版推薦,現金球版推薦,大發網現金版,WG CLUB娛樂城,歐博,沙龍,dg,super,新鑫寶,真人視訊,百家樂,骰寶,賓果,21點,體育賽事,免費影城,老虎機,樂透,北京賽車,手中寶,任你贏彩票,美女主播, av女優、世界盃,棒球12強賽事">
    <meta data-n-head="ssr" data-hid="og:title" property="og:title"
          content="WG CLUB娛樂城│業界誠信高,多款遊戲線上遊戲平台│體育博彩│真人視訊│百家樂│骰寶│六合彩│老虎機">
    <meta data-n-head="ssr" data-hid="og:description" property="og:description"
          content="WG CLUB爲亞洲最大在線合法網上博弈娛樂平台。安全便利, 信譽最佳保證出金，WG CLUB提供各種最新真人視訊百家樂、電子遊戲、SLOT-game、線上六合彩、高賠率運動賽事等賽事遊戲無限，體育直播以及24小時線上客服。">
    <meta data-n-head="ssr" data-hid="mobile-web-app-capable" name="mobile-web-app-capable" content="yes">
    <meta data-n-head="ssr" data-hid="apple-mobile-web-app-capable" name="apple-mobile-web-app-capable" content="yes">
    <meta data-n-head="ssr" data-hid="apple-mobile-web-app-status-bar-style"
          name="apple-mobile-web-app-status-bar-style" content="default">
    <meta data-n-head="ssr" data-hid="apple-mobile-web-app-title" name="apple-mobile-web-app-title" content="WG CLUB娛樂城">
    <meta data-n-head="ssr" data-hid="description" name="description"
          content="WG CLUB爲亞洲最大在線合法網上博弈娛樂平台。安全便利, 信譽最佳保證出金，WG CLUB提供各種最新真人視訊百家樂、電子遊戲、SLOT-game、線上六合彩、高賠率運動賽事等賽事遊戲無限，體育直播以及24小時線上客服。">
    <meta data-n-head="ssr" data-hid="theme-color" name="theme-color" content="#000000">
    <meta data-n-head="ssr" data-hid="og:type" name="og:type" property="og:type" content="website">
    <meta data-n-head="ssr" data-hid="og:site_name" name="og:site_name" property="og:site_name" content="WG CLUB娛樂城">
    <link rel="preload" href="/resource/5bc3753.js" as="script">
    <link rel="preload" href="/resource/98d7b69.js" as="script">
    <link rel="preload" href="/resource/c00de8f.js" as="script">
    <link rel="preload" href="/resource/894b17a.js" as="script">
    <link rel="preload" href="/resource/1648fa8.js" as="script">
    
    <script charset="utf-8" src="/resource/d209228.js"></script>
    <script charset="utf-8" src="/resource/4812f31.js"></script>
    <script charset="utf-8" src="/resource/7a48820.js"></script>
    <link type="text/css" rel="stylesheet" charset="UTF-8" href="/resource/translateelement.css">
    <script charset="utf-8" src="/resource/067c7a3.js"></script>
    <script charset="utf-8" src="/resource/1b16e78.js"></script>
    <style>
        .top_nav h5 img {
            margin-top: 10px;
        }
    </style>
</head>
<body class="s-app">
<div id="__nuxt"><!---->
    <div id="__layout">
        <div data-fetch-key="0">
            <div data-app="true" id="app" class="v-application v-application--is-ltr theme--dark">
                <div class="v-application--wrap">
                    @include('web.layouts.header_q8')
                    <main class="v-main"  data-booted="true">
                        <div class="v-main__wrap">
                            <div role="dialog" class="v-dialog__container UiAnnouncement"></div>
                            <div data-fetch-key="1" id="activity" class="container"><!---->
                                <div role="dialog" class="v-dialog__container"><!----></div>
                                <div role="dialog" class="v-dialog__container"><!----></div>
                                <div role="dialog" class="v-dialog__container"><!----></div>
                                <div class="mx-auto v-sheet theme--dark transparent" style="max-width:1280px;">
                                    <div class="d-flex justify-center align-center pa-4"><h2><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">{{trans("lang.yhhd")}}</font></font></h2></div>
                                    <hr role="separator" aria-orientation="horizontal" class="v-divider theme--dark">
                                    <div class="row">
                                        <div mt-5="" class="col-lg-3 col-12">
                                            <div class="filter v-card v-sheet theme--dark" id="UiFilterLists">
                                                <div role="list"
                                                     class="v-list v-sheet theme--dark v-list--dense v-list--nav">
                                                    <div role="listbox"
                                                         class="v-item-group theme--dark v-list-item-group primary--text">
                                                        <div tabindex="0" role="listitem" aria-selected="true"
                                                             class="v-list-item
@if (!request() -> get('type')) v-item--active v-list-item--active @endif v-list-item--link theme--dark">
                                                            <div class="v-list-item__content category2222" data-type=""><font
                                                                        style="vertical-align: inherit;"><font
                                                                            style="vertical-align: inherit;">{{trans("lang.all")}}</font></font>
                                                            </div>
                                                        </div>
                                                        @foreach(config('platform.activity_type') as $k => $v)
                                                        <div tabindex="0" role="listitem" @if (request() -> get('type') == $k) aria-selected="true" @endif
                                                             class="v-list-item v-list-item--link theme--dark @if (request() -> get('type')== $k) v-item--active v-list-item--active @endif ">
                                                            <div class="v-list-item__content category2222" data-type="{{$k}}">
                                                                <font style="vertical-align: inherit;">
                                                                    <font style="vertical-align: inherit;">{{$v}}</font>
                                                                </font>
                                                            </div>
                                                        </div>
                                                        @endforeach

                                                    </div> <!----></div>
                                            </div>
                                        </div>
                                        <div class="card-item-list col-lg-9 col-12">
                                              @foreach($data as $item)
                                            <div tabindex="0" class="mb-5 v-card v-card--link v-sheet theme--dark" onclick="showDetails({{$item->id}},'{{$item->title}}','{{$item->category}}','{{$item->title_img}}','{{$item->start_at}}','{{$item->end_at}}','{{$item->content}}','{{$item->is_apply}}');" >
                                                <div class="v-image v-responsive img-block theme--dark">
                                                    <div class="v-responsive__sizer"
                                                         style="padding-bottom: 34.2188%;"></div>
                                                    <div class="v-image__image v-image__image--contain"
                                                         style="background-image: url('{{ $item->title_img }}'); background-position: center center;"></div>
                                                    <div class="v-responsive__content" style="width: 1280px;"></div>
                                                </div>
                                                <div class="v-card__title">
                                                    <div class="title"><font style="vertical-align: inherit;"><font
                                                                    style="vertical-align: inherit;">{{ $item->title }}</font></font>
                                                    </div>
                                                </div>
                                                <div class="v-card__text"><span draggable="false"
                                                                                class="activity-label red darken-3 v-chip v-chip--label v-chip--no-color theme--dark v-size--small"><span
                                                                class="v-chip__content"><font
                                                                    style="vertical-align: inherit;"><font
                                                                        style="vertical-align: inherit;">{{ $item->category }}</font></font></span></span>
                                                    <div class="caption text-left"><font
                                                                style="vertical-align: inherit;"><font
                                                                    style="vertical-align: inherit;">
                                                                {{trans("lang.hdqj")}}：{{ $item->start_at }} ~ {{ $item->end_at }}
                                                            </font></font></div>
                                                </div> <!---->
                                            </div>
                                            @endforeach
                                             <!--<nav role="navigation" aria-label="分页导航">
                                                <ul class="v-pagination theme--dark">
                                                    <li>
                                                        <button type="button" aria-label="上一頁"
                                                                class="v-pagination__navigation v-pagination__navigation--disabled">
                                                            <i aria-hidden="true"
                                                               class="v-icon notranslate mdi mdi-chevron-left theme--dark"></i>
                                                        </button>
                                                    </li>
                                                    <li>
                                                        <button type="button" aria-current="true" aria-label="當前頁 1"
                                                                class="v-pagination__item v-pagination__item--active primary">
                                                            <font style="vertical-align: inherit;"><font
                                                                        style="vertical-align: inherit;">1</font></font>
                                                        </button>
                                                    </li>
                                                    <li>
                                                        <button type="button" aria-label="下一頁"
                                                                class="v-pagination__navigation v-pagination__navigation--disabled">
                                                            <i aria-hidden="true"
                                                               class="v-icon notranslate mdi mdi-chevron-right theme--dark"></i>
                                                        </button>
                                                    </li>
                                                </ul>
                                            </nav>-->
                                            
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            
               
                            <div id="UiMarquee" clipped-right="" app="" bottom=""
                                 class="d-flex align-center v-sheet theme--dark transparent fixed" data-v-0b083737="">
                                <button type="button"
                                        class="v-btn v-btn--flat v-btn--icon v-btn--round theme--dark v-size--small"
                                        data-v-0b083737=""><span class="v-btn__content"><i aria-hidden="true"
                                                                                           class="v-icon notranslate mdi mdi-bullhorn-outline theme--dark"
                                                                                           data-v-0b083737=""></i></span>
                                </button>
                                <div data-v-0b083737="" class="flex-grow-1 marquee-text-wrap">
                                    <div data-v-0b083737="" class="marquee-text-content">
                                        <div data-v-0b083737="" class="marquee-text-text"
                                             style="animation-duration: 176.7s;">

                                            @foreach($_system_notices as $v)
                                                <span data-v-0b083737="" class="ml-0">
                                                <!--<span data-v-0b083737="" class="marquee-category ml-2">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">系统公告</font>
                                                    </font>
                                                </span>-->
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">{{ $v->title }}</font>
                                                    <font style="vertical-align: inherit;">{{ $v->content }}</font>
                                                </font>
                                            </span>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                      @include('web.layouts.footer_q8')
                </div>
             
        </div>
                
            </div>
        </div>
    </div>
</div>
<script>
         function showDetails(id,title,category,image,start,end,content,is_apply){
            console.log(content)
            $("#a_title").text(title);
            $("#a_category").text(category);
            $("#a_image").css("background-image",'url(' + image + ')');
            $("#a_start").text(start);
            $("#a_end").text(end);
            $("#a_content").html(content);
            vid = id;
            $("#active_").show();
            if(is_apply==1){
                $('.joinActive').hide();
            }else{
                $('.joinActive').show();
            }
        }
    $(function(){
       $(".notice_close").on('click',function(){
            $("#active_").hide();
        })
        
       $('.joinActive').click(function(){
            if(vid!=0){
                $.ajax({
                    url:"{{ route('member.apply_activity') }}",
                    type:'post',
                    data:{activity_id:vid},
                    success:function(data){
						if(data.status.errorCode == 0){
							chenggong_alert(1,data.status.msg);
						}
						else{
							chenggong_alert(2,data.status.msg);
						}
                    }
                })
            }
        })
        
        $(".active-close").on('click',function(){
            $("#detailV").hide();
        })

         $(".v-card--link").on('click',function(){
            var id = $(this).attr('data-id');
            $("#8888box11").attr('src','/activity/'+id);
             $("#detailV").show();
        })

          $(".category2222").on('click',function(){
            var type = $(this).attr('data-type');
            window.location.href="/activities?type="+type
        })
    })
</script>
</body>
</html>
