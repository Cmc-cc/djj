<html class="no-js"><!--<![endif]-->
<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="/new0404/pc/css/normalize.css">
    <link rel="stylesheet" href="/new0404/pc/css/main.css">
    <link rel="stylesheet" href="/new0404/pc/css/register.css">
    <link rel="stylesheet" href="/new0404/pc/css/loadingTrack.css">
    <link rel="stylesheet" href="/new0404/pc/css/loading.css">
    <link rel="stylesheet" href="/new0404/pc/css/main-1440.css" media="screen and (max-width:1600px)">
    <link rel="stylesheet" href="/new0404/pc/css/language_tw.css" id="languageCss">
    <style>
        html,
        body {
            overflow: hidden;
            overflow-y: auto;
        }

        body {
            background: #000;
            padding: 10px;
            background-image: url("/new0404/pc/images/01.jpg");
        }
    </style>
</head>
<body>
<div style="width: 670px;" class="helpWord">
    <div class="helpWord-c2">
        <div class="helpWord">
            <div class="subject text_267"></div>
            <div class="main-bd">
                <h1 class="text_365"></h1>
                <div class="text_724"></div>
                <br>
                <br>

                <h1 class="text_367"></h1>
                <div class="text_368"></div>
                <div class="text_369"></div>
                <div class="text_370"></div>
                <div class="text_371"></div>
                <div class="text_372"></div>
                <br>
                <br>

                <h1 class="text_373"></h1>
                <div class="text_374"></div>
                <div class="text_375"></div>
                <br>
                <br>

                <h1 class="text_376"></h1>
                <div class="text_377"></div>
                <br>
                <br>

                <h1 class="text_378"></h1>
                <div>
                    <span>1、</span>
                    <div class="plmt text_379"></div>
                </div>
                <div>
                    <span>2、</span>
                    <div class="plmt text_380"></div>
                </div>
                <div>
                    <span>3、</span>
                    <div class="plmt text_381"></div>
                </div>
                <div>
                    <span>4、</span>
                    <div class="plmt text_382"></div>
                </div>
                <div>
                    <span>5、</span>
                    <div class="plmt text_383"></div>
                </div>
                <div>
                    <span>6、</span>
                    <div class="plmt text_384"></div>
                </div>
                <div>
                    <span>7、</span>
                    <div class="plmt text_385"></div>
                </div>
                <div>
                    <span>8、</span>
                    <div class="plmt text_386"></div>
                </div>
                <br>
                <br>

                <h1 class="text_387"></h1>
                <div>
                    <span>1、</span>
                    <div class="plmt text_388">：</div>
                </div>
                <div style="padding-left: 20px;">
                    <span>A、</span>
                    <div class="plmt text_389"></div>
                </div>
                <div style="padding-left: 20px;">
                    <span>B、</span>
                    <div class="plmt text_390"></div>
                </div>
                <div style="padding-left: 20px;">
                    <span>C、</span>
                    <div class="plmt text_391"></div>
                </div>
                <div style="padding-left: 20px;">
                    <span>D、</span>
                    <div class="plmt text_392"></div>
                </div>
                <div>
                    <span>2、</span>
                    <div class="plmt text_393"></div>
                </div>
                <div>
                    <span>3、</span>
                    <div class="plmt text_394"></div>
                </div>
                <div>
                    <span>4、</span>
                    <div class="plmt text_395"></div>
                </div>
                <div>
                    <span>5、</span>
                    <div class="plmt text_396"></div>
                </div>
                <div>
                    <span>6、 </span>
                    <div class="plmt text_397"></div>
                </div>
                <div>
                    <span>◆</span>
                    <div class="plmt text_398"></div>
                </div>
                <br>
                <br>

                <div style="float: right" class="text_399"></div>
                <br>
            </div>
        </div>
    </div>
</div>


</body>
</html>