<!DOCTYPE html>
<!-- saved from url=(0015)/ -->
<html class="s-app translated-ltr" lang="zh-CN" data-n-head="%7B%22lang%22:%7B%22ssr%22:%22zh-TW%22%7D%7D">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <title>{{ $_system_config->site_title  or 'motoo' }}</title>
    <meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1">
    <meta data-n-head="ssr" data-hid="og:url" property="og:url" content="https://q8.bet">
    <meta data-n-head="ssr" data-hid="keywords" name="keywords"
          content="娛樂城體育,娛樂城優惠,線上娛樂城,娛樂城註冊優惠,現金版推薦,現金球版推薦,大發網現金版,WG CLUB娛樂城,歐博,沙龍,dg,super,新鑫寶,真人視訊,百家樂,骰寶,賓果,21點,體育賽事,免費影城,老虎機,樂透,北京賽車,手中寶,任你贏彩票,美女主播, av女優、世界盃,棒球12強賽事">
    <meta data-n-head="ssr" data-hid="og:title" property="og:title"
          content="WG CLUB娛樂城│業界誠信高,多款遊戲線上遊戲平台│體育博彩│真人視訊│百家樂│骰寶│六合彩│老虎機">
    <meta data-n-head="ssr" data-hid="og:description" property="og:description"
          content="WG CLUB爲亞洲最大在線合法網上博弈娛樂平台。安全便利, 信譽最佳保證出金，WG CLUB提供各種最新真人視訊百家樂、電子遊戲、SLOT-game、線上六合彩、高賠率運動賽事等賽事遊戲無限，體育直播以及24小時線上客服。">
    <meta data-n-head="ssr" data-hid="mobile-web-app-capable" name="mobile-web-app-capable" content="yes">
    <meta data-n-head="ssr" data-hid="apple-mobile-web-app-capable" name="apple-mobile-web-app-capable" content="yes">
    <meta data-n-head="ssr" data-hid="apple-mobile-web-app-status-bar-style"
          name="apple-mobile-web-app-status-bar-style" content="default">
    <meta data-n-head="ssr" data-hid="apple-mobile-web-app-title" name="apple-mobile-web-app-title" content="WG CLUB娛樂城">
    <meta data-n-head="ssr" data-hid="description" name="description"
          content="WG CLUB爲亞洲最大在線合法網上博弈娛樂平台。安全便利, 信譽最佳保證出金，WG CLUB提供各種最新真人視訊百家樂、電子遊戲、SLOT-game、線上六合彩、高賠率運動賽事等賽事遊戲無限，體育直播以及24小時線上客服。">
    <meta data-n-head="ssr" data-hid="theme-color" name="theme-color" content="#000000">
    <meta data-n-head="ssr" data-hid="og:type" name="og:type" property="og:type" content="website">
    <meta data-n-head="ssr" data-hid="og:site_name" name="og:site_name" property="og:site_name" content="WG CLUB娛樂城">
    <link data-n-head="ssr" data-hid="shortcut-icon" rel="shortcut icon">
    <link type="text/css" rel="stylesheet" href="/css/swiper.min.css">
    <script type="text/javascript" src="/new/css/swiper.min.js"></script>
    <style>
        .top_nav h5 img {
            margin-top: 10px;
        }
        		.ta_c{
			    text-align: center;
			}
            
            @-webkit-keyframes rotation{
            from {-webkit-transform: rotate(0deg);}
            to {-webkit-transform: rotate(360deg);}
            }
            
            .Rotation{
            -webkit-transform: rotate(360deg);
            animation: rotation 3s linear infinite;
            -moz-animation: rotation 3s linear infinite;
            -webkit-animation: rotation 3s linear infinite;
            -o-animation: rotation 3s linear infinite;
            }
            .v-application .accent {
                background-color: var(--v-accent-base) !important;
                border-color: var(--v-accent-base) !important;
            }
            
    </style>
</head>
<body class="s-app">
<div id="__nuxt"><!---->
    <div id="__layout">
        <div data-fetch-key="0">
            <div data-app="true" id="app" class="v-application v-application--is-ltr theme--dark">
                <div class="v-application--wrap">
                    @include('web.layouts.header_q8')
                    <main class="v-main"  data-booted="true">
                        <div class="v-main__wrap">
                            <div role="dialog" class="v-dialog__container UiAnnouncement"></div>
                            <div data-fetch-key="1">
                                
                                
                                    <div class="swiper-container" style="height: 60vh; overflow:hidden;">
                                        <div class="swiper-wrapper">
                                       <!-- 图片列表容器 -->
                                       @foreach($banners as $key=>$item)
                                     
                                       <div class="swiper-slide" style=" height: 60vh;
    background-size: 100% 100%;background-image: url('{{ $item->path }}'); background-position: center center;">
                                         
                                       </div>
                                       
                                       @endforeach
                                       </div>
                                    </div>
<script>
var swiper = new Swiper('.swiper-container', {
    paginationClickable: true,
    autoplay: true,
    loop: true
});
</script>
                                
                                <div class="decoLine2"></div>
                                <div id="UiLiveStream" data-v-fa8d5078="">
                                    <div class="d-flex justify-center" data-v-fa8d5078="">
                                        <div class="s-live shiny sport-live-mask mx-3" data-v-fa8d5078=""><img
                                                src="./resource/s-sport-live.0e26328.png"
                                                class="animate__animated animate__faster" data-v-fa8d5078="">
                                            <div class="liveText" data-v-fa8d5078="">
                                                <div data-v-fa8d5078=""><font style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">体育直播</font></font></div>
                                                <span data-v-fa8d5078=""><font style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">S-SPORT LIVE</font></font></span>
                                            </div>
                                            <div top="0px" class="v-overlay v-overlay--absolute theme--dark"
                                                 style="z-index:5;" data-v-fa8d5078="">
                                                <div class="v-overlay__scrim"
                                                     style="opacity:0;background-color:#212121;border-color:#212121;"></div>
                                            </div>
                                        </div>
                                        <div class="s-live shiny cinema-mask mx-3" data-v-fa8d5078=""><img
                                                src="./resource/s-cinema.8f7948b.png"
                                                class="animate__animated animate__faster" data-v-fa8d5078="">
                                            <div class="liveText" data-v-fa8d5078="">
                                                <div data-v-fa8d5078=""><font style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">影城</font></font></div>
                                                <span data-v-fa8d5078=""><font style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">S-CINEMA</font></font></span>
                                            </div>
                                            <div class="v-overlay v-overlay--absolute theme--dark" style="z-index:5;"
                                                 data-v-fa8d5078="">
                                                <div class="v-overlay__scrim"
                                                     style="opacity:0;background-color:#212121;border-color:#212121;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="UiGameCategory" class="mx-auto mt-10 v-sheet theme--dark transparent"
                                     style="max-width:1280px;" data-v-2ac1132f="">
                                    <div class="text-center text-uppercase" data-v-2ac1132f=""><p class="text-lg-h3"
                                                                                                  data-v-2ac1132f="">
                                        <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">{{trans("lang.youxizhonglei")}}</font></font>
                                    </p>
                                        <p class="primary--text categoryDeo" style="letter-spacing:20px;"
                                           data-v-2ac1132f=""><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">Welcome</font></font></p></div>
                                    <div class="d-flex justify-center flex-wrap" data-v-2ac1132f=""><a
                                            href="/sport"
                                            class="gameCatetory ma-2 animate__animated animate__faster"
                                            data-v-2ac1132f="">
                                        <div class="v-skeleton-loader theme--dark" data-v-2ac1132f="">
                                            <div class="v-image v-responsive theme--dark" data-v-2ac1132f="">
                                                <div class="v-responsive__sizer"
                                                     style="padding-bottom: 110.584%;"></div>
                                                <div class="v-image__image v-image__image--cover"
                                                     style="background-image: url(./resource/sport.18157d8.png); background-position: center center;"></div>
                                                <div class="v-responsive__content" style="width: 274px;">
                                                    <div class="descript" data-v-2ac1132f="">
                                                        <div class="itemName text-h5" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">{{trans("lang.tiyu")}}</font></font></div>
                                                        <span class="text-uppercase" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">sport</font></font></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a><a href="/live"
                                           class="gameCatetory ma-2 animate__animated animate__faster"
                                           data-v-2ac1132f="">
                                        <div class="v-skeleton-loader theme--dark" data-v-2ac1132f="">
                                            <div class="v-image v-responsive theme--dark" data-v-2ac1132f="">
                                                <div class="v-responsive__sizer"
                                                     style="padding-bottom: 110.584%;"></div>
                                                <div class="v-image__image v-image__image--cover"
                                                     style="background-image: url(./resource/live.0e64262.png); background-position: center center;"></div>
                                                <div class="v-responsive__content" style="width: 274px;">
                                                    <div class="descript" data-v-2ac1132f="">
                                                        <div class="itemName text-h5" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">{{trans("lang.zhenren")}}</font></font></div>
                                                        <span class="text-uppercase" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">live</font></font></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a><a href="/e-battle"
                                           class="gameCatetory ma-2 animate__animated animate__faster"
                                           data-v-2ac1132f="">
                                        <div class="v-skeleton-loader theme--dark" data-v-2ac1132f="">
                                            <div class="v-image v-responsive theme--dark" data-v-2ac1132f="">
                                                <div class="v-responsive__sizer"
                                                     style="padding-bottom: 110.584%;"></div>
                                                <div class="v-image__image v-image__image--cover"
                                                     style="background-image: url(./resource/e-battle.7871cc5.png); background-position: center center;"></div>
                                                <div class="v-responsive__content" style="width: 274px;">
                                                    <div class="descript" data-v-2ac1132f="">
                                                        <div class="itemName text-h5" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">{{trans("lang.qipai")}}</font></font></div>
                                                        <span class="text-uppercase" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">e-battle</font></font></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a><a href="/keno"
                                           class="gameCatetory ma-2 animate__animated animate__faster"
                                           data-v-2ac1132f="">
                                        <div class="v-skeleton-loader theme--dark" data-v-2ac1132f="">
                                            <div class="v-image v-responsive theme--dark" data-v-2ac1132f="">
                                                <div class="v-responsive__sizer"
                                                     style="padding-bottom: 110.584%;"></div>
                                                <div class="v-image__image v-image__image--cover"
                                                     style="background-image: url(./resource/keno.8ea9cbf.png); background-position: center center;"></div>
                                                <div class="v-responsive__content" style="width: 274px;">
                                                    <div class="descript" data-v-2ac1132f="">
                                                        <div class="itemName text-h5" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">{{trans("lang.caipiao")}}</font></font></div>
                                                        <span class="text-uppercase" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">keno</font></font></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a><a href="/e-game"
                                           class="gameCatetory ma-2 animate__animated animate__faster"
                                           data-v-2ac1132f="">
                                        <div class="v-skeleton-loader theme--dark" data-v-2ac1132f="">
                                            <div class="v-image v-responsive theme--dark" data-v-2ac1132f="">
                                                <div class="v-responsive__sizer"
                                                     style="padding-bottom: 110.584%;"></div>
                                                <div class="v-image__image v-image__image--cover"
                                                     style="background-image: url(./resource/e-game.79c0dd0.png); background-position: center center;"></div>
                                                <div class="v-responsive__content" style="width: 274px;">
                                                    <div class="descript" data-v-2ac1132f="">
                                                        <div class="itemName text-h5" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">{{trans("lang.dianzi")}}</font></font></div>
                                                        <span class="text-uppercase" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">e-game</font></font></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a><a href="/fishing"
                                           class="gameCatetory ma-2 animate__animated animate__faster"
                                           data-v-2ac1132f="">
                                        <div class="v-skeleton-loader theme--dark" data-v-2ac1132f="">
                                            <div class="v-image v-responsive theme--dark" data-v-2ac1132f="">
                                                <div class="v-responsive__sizer"
                                                     style="padding-bottom: 110.584%;"></div>
                                                <div class="v-image__image v-image__image--cover"
                                                     style="background-image: url(./resource/fishing.df85355.png); background-position: center center;"></div>
                                                <div class="v-responsive__content" style="width: 274px;">
                                                    <div class="descript" data-v-2ac1132f="">
                                                        <div class="itemName text-h5" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">{{trans("lang.buyu")}}</font></font></div>
                                                        <span class="text-uppercase" data-v-2ac1132f=""><font
                                                                style="vertical-align: inherit;"><font
                                                                style="vertical-align: inherit;">fishing</font></font></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a></div>
                                </div> <!----></div>
                            <div id="UiMarquee" clipped-right="" app="" bottom=""
                                 class="d-flex align-center v-sheet theme--dark transparent fixed" data-v-0b083737="">
                                <button type="button"
                                        class="v-btn v-btn--flat v-btn--icon v-btn--round theme--dark v-size--small"
                                        data-v-0b083737=""><span class="v-btn__content"><i aria-hidden="true"
                                                                                           class="v-icon notranslate mdi mdi-bullhorn-outline theme--dark"
                                                                                           data-v-0b083737=""></i></span>
                                </button>
                                <div data-v-0b083737="" class="flex-grow-1 marquee-text-wrap">
                                    <div data-v-0b083737="" class="marquee-text-content">
                                        <div data-v-0b083737="" class="marquee-text-text"
                                             style="animation-duration: 176.7s;">
                                            @foreach($_system_notices as $v)
                                            <span data-v-0b083737="" class="ml-0">
                                                <span data-v-0b083737="" class="marquee-category ml-2">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">{{trans("lang.xtgg")}}</font>
                                                    </font>
                                                </span>
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">{{ $v->title }}</font>
                                                    <font style="vertical-align: inherit;">{{ $v->content }}</font>
                                                </font>
                                            </span>
                                            @endforeach
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                     @include('web.layouts.footer_q8')
                </div>
                    @if($_system_notices)
                    <div role="document" tabindex="0" class="v-dialog__content v-dialog__content--active" style="z-index: 202;">
                        <div class="v-dialog v-dialog--active v-dialog--scrollable" style="transform-origin: center center; max-width: 600px;">
                            <div class="v-card v-sheet theme--dark">
                                <div class="v-card__title">
                                    <button type="button" onclick="hideTc();" class="v-btn v-btn--absolute v-btn--fab v-btn--flat v-btn--icon v-btn--right v-btn--round theme--dark v-size--default primary--text">
                                        <span class="v-btn__content"><i aria-hidden="true" class="v-icon notranslate mdi mdi-close theme--dark"></i></span>
                                    </button> 
                                    <div>
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">{{trans("lang.xtgg")}}</font>
                                        </font>
                                    </div>
                                </div>
                                <div class="v-card__title">
                                    <font style="vertical-align: inherit;">
                                        <font style="vertical-align: inherit;" id="notice_title">{{$_system_notices[0]['title']}}</font>
                                    </font>
                                </div> 
                                <div class="v-card__text v-html" style="height: 30vh;">
                                    <p>
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;" id="notice_content">{{$_system_notices[0]['content']}}</font>
                                        </font>
                                        <br>
                                    </p>
                                </div> 
                                <div class="v-card__actions">
                                    <button type="button" onclick="pre();" id="pre_2" style="display:none;" class="v-btn v-btn--contained theme--dark v-size--default accent">
                                        <span class="v-btn__content">
                                            <font style="vertical-align: inherit;">
                                                 <font style="vertical-align: inherit;" >{{trans("lang.shangyige")}}</font>
                                            </font>
                                        </span>
                                    </button>
                                    @if(count($_system_notices)>1)
                                    <button type="button" onclick="next();" id="next_2" class="v-btn v-btn--contained theme--dark v-size--default accent">
                                        <span class="v-btn__content">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">{{trans("lang.xiayige")}}</font>
                                            </font>
                                        </span>
                                    </button>
                                    @endif
                                </div>
                        </div>
                    </div>
                </div>
                    @endif  
    </div>
</div>
<script>
    function hideTc(){
        $(".v-dialog__content--active").hide();
    }
     var notices = '{!!$_system_notices!!}';
        var notObj = JSON.parse(notices);
      
        var currenctIndex=0;
        function pre(){
            if(currenctIndex>0){
                currenctIndex--;
            }
            if(currenctIndex==0){
                $("#pre_2").hide();
            }
            console.log(notObj[currenctIndex])
            $("#next_2").removeClass('accent').addClass('accent');
            $("#notice_title").html(notObj[currenctIndex].title);
            $("#notice_content").html(notObj[currenctIndex].content);
        }
        function next(){
            if(notObj.length-1>currenctIndex){
                currenctIndex++;
                $("#pre_2").show();
            }
            console.log(notObj[currenctIndex])
            $("#notice_title").html(notObj[currenctIndex].title);
            $("#notice_content").html(notObj[currenctIndex].content);
            if(currenctIndex==notObj.length-1){
                $("#next_2").removeClass('accent');
            }
        }
</script>
</body>
</html>
