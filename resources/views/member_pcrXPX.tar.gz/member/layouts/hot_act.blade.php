<div class="hot_act">
    <h2>热门活动</h2>
    <ul>
        <li>
            <a href="#">
                <img src="{{ asset('/web/images/n-reg-hd1a.jpg') }}">
                <p class="title">用户首存优惠 最高58%等您来拿</p>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="{{ asset('/web/images/n-reg-hd2a.jpg') }}">
                <p class="title">天天洗码无上限！超高返水1.7%</p>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="{{ asset('/web/images/n-reg-hd3a.jpg') }}">
                <p class="title">复活礼金 战斗中复活助您一臂之力</p>
            </a>
        </li>
    </ul>
</div>