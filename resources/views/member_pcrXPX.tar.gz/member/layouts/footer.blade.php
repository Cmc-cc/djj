
<div class="tb-foot-1">
    <ul class="container">
        <li>
            <a href="javascript:;">
                <div class="pullLeft bg-icon ft-ico-1"></div>
                <h2>试玩体验</h2>
                <p>上百款游戏，不用花钱照样玩！</p>
            </a>
        </li>
        <li>
            <a href="javascript:;">
                <div class="pullLeft bg-icon ft-ico-2"></div>
                <h2>试玩体验</h2>
                <p>上百款游戏，不用花钱照样玩！</p>
            </a>
        </li>
        <li>
            <a href="javascript:;">
                <div class="pullLeft bg-icon ft-ico-3"></div>
                <h2>试玩体验</h2>
                <p>上百款游戏，不用花钱照样玩！</p>
            </a>
        </li>
        <li>
            <a href="javascript:;">
                <div class="pullLeft bg-icon ft-ico-4"></div>
                <h2>试玩体验</h2>
                <p>上百款游戏，不用花钱照样玩！</p>
            </a>
        </li>
    </ul>
</div>

<div class="footer">
    <div class="container">
        <ul class="clear">
            <li>
                <div class="title">
                    <h2>合作伙伴</h2>
                </div>
                <h4>博彩机构</h4>
                <span class="foot-logo foot-logo_1">
            <em class="bg-icon"></em>
          </span>
                <span class="foot-logo foot-logo_2">
            <em class="bg-icon"></em>
          </span>
                <span class="foot-logo foot-logo_3">
            <em class="bg-icon"></em>
          </span>
                <span class="foot-logo foot-logo_4">
            <em class="bg-icon"></em>
          </span>
                <span class="foot-logo foot-logo_5">
            <em class="bg-icon"></em>
          </span>
                <span class="foot-logo foot-logo_6">
            <em class="bg-icon"></em>
          </span>
                <h4>博彩责任</h4>
                <span class="foot-logo foot-logo_7">
            <em class="bg-icon"></em>
          </span>
                <span class="foot-logo foot-logo_8">
            <em class="bg-icon"></em>
          </span>
            </li>
            <li>
                <div class="title">
                    <h2>产品优势</h2>
                </div>
                <div class="foot-game">
                    <em>真人娱乐城</em>
                    <p>腾博会提供多个最受欢迎的真人娱乐场游戏，包括真人娱乐百家乐﹑二十一点﹑骰宝﹑龙虎及轮盘等等游戏。 我们还为您提供VIP至尊包桌服务，
                        可咪牌，自由飞牌，任换荷官，任换牌靴等。</p>
                </div>
                <div class="foot-game">
                    <em>老虎机及電子游戏</em>
                    <p>游戏包括轮盘、21点、電子扑克、老虎机等在线娱乐场游戏，丰厚的累积奖池与超高积分让您体验更刺激的游戏乐趣。</p>
                </div>
            </li>
            <li>
                <div class="title">
                    <h2>产品优势</h2>
                </div>
                <div class="foot-phone">
                    <span class="bg-icon bg-icon-tel_1"></span>
                    400-
                </div>
                <a href="javascript:;" class="bg-icon bg-icon-qq">在线客服</a>
            </li>
        </ul>
    </div>
</div>
<div class="footer-ft clear">
    <div class="container">
        <div class="pullRight">
            <ul>
                <li><a href="javascript:;">关于腾博会</a></li>
                <li><a href="javascript:;">联络我们</a></li>
                <li><a href="javascript:;">代理合作</a></li>
                <li><a href="javascript:;">存款帮助</a></li>
                <li><a href="javascript:;">取款帮助</a></li>
                <li><a href="javascript:;">常见问题</a></li>
            </ul>
        </div>
    </div>
</div>