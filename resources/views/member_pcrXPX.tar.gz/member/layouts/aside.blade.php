<div class="aside">
    <div>
        <a href="javascript:;" class="aside_kefu on">
            <span class="bg-icon"></span>
            <p>在线客服</p>
        </a>
        <a href="javascript:;" class="aside_qq">
            <span class="bg-icon"></span>
            <p>QQ客服</p>
        </a>
        <a href="javascript:;" class="aside_phone">
            <span class="bg-icon"></span>
            <p>客户端</p>
        </a>
    </div>
</div>